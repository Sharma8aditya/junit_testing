package junit_testPackage;
public class junit_testing{
	public int addnumbers(int num_1, int num_2)
	{
		return num_1+num_2; 
	}
	
	public String addstring(String s1, String s2)
	{
		return s1+s2;
	}
}