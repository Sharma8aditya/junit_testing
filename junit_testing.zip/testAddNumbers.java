package junit_testPackage;

import static org.junit.Assert.*;

import org.junit.Test;

public class testAddNumbers {

	@Test
	public void test() {
		junit_testing junit=new junit_testing();
	    int result=junit.addnumbers(100, 200);
	    assertEquals(300, result);
	}

}