package junit_testPackage;

import static org.junit.Assert.*;

import org.junit.Test;

public class junit_addstring {

	@Test
	public void test() {
		junit_testing junit = new junit_testing();
	    String result = junit.addstring("hello", "hi");
	    assertEquals("hellohi", result);
	}

}